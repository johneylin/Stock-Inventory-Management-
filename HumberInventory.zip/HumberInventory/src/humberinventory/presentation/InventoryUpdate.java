/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humberinventory.presentation;
import humberinventory.business.*;
import javafx.application.Application;
import javafx.geometry.Insets;
import javafx.geometry.Pos;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TextField;
import javafx.scene.control.Tooltip;
import javafx.scene.layout.GridPane;
import javafx.stage.Stage;

/**
 *
 * @author Junyu
 */
public class InventoryUpdate extends Application{
     GridPane gp = new GridPane();
        Label lblProdCode = null;
        Label lblProdName = null;
        Label lblProdDesc = null;
        Label lblQuantity = null;
        Label lblPrice = null;
        Label lblCost;
        Label lblDiscount = null;
        TextField txtProdCode = null;
        TextField txtProdName = null;
        TextField txtProdDesc = null;
        TextField txtQuantity = null;
        TextField txtCost=null;
        TextField txtPrice = null;
        TextField txtDiscount = null;
        Button btnUpdate = null;
        Button btnClear = null;
        int check = 0;
        BCommunicator bCom;
        Product product;
        InventoryView changedView;
    InventoryUpdate(){
        
    }
    InventoryUpdate(Product prod){
        this.product=prod;
    }
        @Override
    public void start(Stage primaryStage){
        lblProdCode = new Label("Product Code: ");
        lblProdName = new Label("Product Name: ");
        lblProdDesc = new Label("Product Description: ");
        lblQuantity = new Label("Quantity: ");
        lblCost = new Label("Cost: ");
        lblPrice = new Label("Price: ");
        lblDiscount = new Label("Discount: ");
        txtProdCode = new TextField(this.product.getProductCode());
        txtProdName = new TextField(this.product.getProductName());
        txtProdDesc = new TextField(this.product.getProductDesc());
        txtQuantity = new TextField(Integer.toString(this.product.getQuantity()));
        txtCost = new TextField(Double.toString(this.product.getCost()));
        txtPrice = new TextField(Double.toString(this.product.getRetailPrice()));
        txtDiscount = new TextField(Double.toString(this.product.getDiscount()));
        btnUpdate = new Button("Update");
        btnClear = new Button("Clear");
        btnUpdate.minWidth(140);
        btnClear.minWidth(10);
        gp.setAlignment(Pos.CENTER);
        gp.setHgap(10.0);
        gp.setVgap(10.0);
        gp.setPadding(new Insets(10));
        gp.add(lblProdCode,0,1);
        gp.add(txtProdCode,1,1);
        gp.add(lblProdName,0,2);
        gp.add(txtProdName,1,2);
        gp.add(lblProdDesc,0,3);
        gp.add(txtProdDesc,1,3);
        gp.add(lblQuantity,0,4);
        gp.add(txtQuantity,1,4);
        gp.add(lblCost,0,5);
        gp.add(txtCost,1,5);
        
        gp.add(lblPrice,0,6);
        gp.add(txtPrice,1,6);
        gp.add(lblDiscount,0,7);
        gp.add(txtDiscount,1,7);
        gp.add(btnUpdate,0,8);
        gp.add(btnClear,1,8);
        
        btnUpdate.setOnAction(e ->{
            if(IsValidData()){
            this.bCom = new BCommunicator();
            check=bCom.updateProduct(this.product.getProductId(),
            this.txtProdCode.getText(),
            this.txtProdName.getText(),this.txtProdDesc.getText(),
            Double.parseDouble(this.txtCost.getText()),
            Integer.parseInt(this.txtQuantity.getText()),
            Double.parseDouble(this.txtPrice.getText()),
            Double.parseDouble(this.txtDiscount.getText()));
            
            changedView = new InventoryView();
            changedView.start(primaryStage);
            }
        });
        btnUpdate.setOnMouseMoved(e ->{
            
        });
        
        btnClear.setOnAction(e ->{
            txtProdCode.setText("");
            txtProdName.setText("");
            txtProdDesc.setText("");
            txtQuantity.setText("");
            txtCost.setText("");
            txtPrice.setText("");
            txtDiscount.setText("");
        });
        Scene scene = new Scene(gp);
        primaryStage.setTitle("Update Product ");
        primaryStage.setScene(scene);
        primaryStage.show();
}
            public boolean IsValidData(){
            validate v = new validate();
            return 
                    v.IsPresent(txtProdCode, "Product Code")&&
                    v.IsPresent(txtProdName, "Product Name")&&
                    v.IsPresent(txtProdDesc, "Product Description")&&
                    v.IsPresent(txtQuantity, "Product Quantity")&&
                    v.IsInteger(txtQuantity, "Product Quantity")&&
                    v.IsPresent(txtCost, "Product Cost")&&
                    v.IsDouble(txtCost, "Product Cost")&&
                    v.IsPresent(txtPrice, "Product Price")&&
                    v.IsDouble(txtPrice, "Product Price")&&
                    v.IsPresent(txtDiscount, "Product Discount")&&                  
                    v.IsDouble(txtDiscount, "Product Discount")&&
                    v.IsWithinRange(txtDiscount, "Product Discount", 0, 100);
        }
}