/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package humberinventory.presentation;
import humberinventory.business.*;

import java.util.ArrayList;
import java.util.List;
import javafx.geometry.Insets;
import javafx.application.Application;
import static javafx.application.Application.launch;
import javafx.collections.FXCollections;
import javafx.collections.ObservableList;
import javafx.scene.Scene;
import javafx.scene.control.Button;
import javafx.scene.control.Label;
import javafx.scene.control.TableColumn;
import javafx.scene.control.TableView;
import javafx.scene.control.cell.PropertyValueFactory;
import javafx.scene.layout.BorderPane;
import javafx.scene.layout.GridPane;
import javafx.scene.layout.HBox;
import javafx.scene.layout.VBox;
import javafx.scene.text.Font;
import javafx.scene.text.FontWeight;
import javafx.stage.Stage;

/**
 *
 * @author Soaib
 */
public class InventoryView extends Application {
    
    
    GridPane gp = new GridPane();
    TableView table = new TableView();
    VBox vb = new VBox();
    HBox hbbottom = new HBox();
    HBox hbtop = new HBox();
    ArrayList prodList ;
    ObservableList<Product> products;
    BCommunicator bCom;
    BorderPane bp = new BorderPane();
    
    Button addProduct = null;
    Button updateProduct = null;
    Button deleteProduct = null;
    Label title = null;
    TableColumn<Product, Integer> productId = null;
    TableColumn<Product, String> productCode = null;
    TableColumn<Product, String>  productName = null;
    TableColumn<Product, Double> productPrice = null;
    TableColumn<Product, Integer> productQuantity = null;
    
    

    @Override
    public void start(Stage primaryStage)  {
        
        addProduct = new Button("Add Product");
        updateProduct = new Button("Update Product");
        deleteProduct = new Button("Delete Product");
        title = new Label("Product List");
        
        title.setFont(Font.font("Arial", FontWeight.BOLD, 20));
        title.setStyle("-fx-text-fill:white");
        
        //Table header columns
        productId = new TableColumn("Product Id");
        productId.setMinWidth(120);
        productId.setCellValueFactory(new PropertyValueFactory<>("productId"));
        
        productCode = new TableColumn("Product Code");
        productCode.setMinWidth(180);
        productCode.setCellValueFactory(new PropertyValueFactory<>("productCode"));
        
        productName = new TableColumn("Product Name");
        productName.setMinWidth(180);
        productName.setCellValueFactory(new PropertyValueFactory<>("productName"));
        
        productPrice = new TableColumn("Product Price");
        productPrice.setMinWidth(180);
        productPrice.setCellValueFactory(new PropertyValueFactory<>("retailPrice"));
        
        productQuantity = new TableColumn("Product Quantity");
        productQuantity.setMinWidth(180);
        productQuantity.setCellValueFactory(new PropertyValueFactory<>("Quantity"));
            
        //top or header
        hbtop.getChildren().add(title);
        hbtop.setSpacing(10);
        hbtop.setPadding(new Insets(15, 12, 15, 12));
        hbtop.setStyle("-fx-background-color: #336699;");
        
        bCom = new BCommunicator();
        prodList=bCom.getProductList();
        products = FXCollections.observableArrayList(prodList);    
        table.getColumns().addAll(productId,productCode,productName,productPrice,productQuantity);
        table.setItems(products);
        vb.getChildren().add(table);
        
        //bottom or Footer
        hbbottom.getChildren().addAll(addProduct,updateProduct,deleteProduct);
        hbbottom.setSpacing(10);
        hbbottom.setPadding(new Insets(15, 12, 15, 12));
        hbbottom.setStyle("-fx-background-color: #336699;");
        
        
        //delete product
        deleteProduct.setOnMouseClicked(e ->
        {
            //Get selected product 
            Product prod = (Product) table.getSelectionModel().getSelectedItem();
            
            //Then Try to delete from database 
            bCom = new BCommunicator();
            bCom.deleteProduct(prod.getProductId());
            products.remove(prod);
           
        });
        // Add Button
        addProduct.setOnMouseClicked(e ->
        {
            InventoryAdd inAdd = new InventoryAdd();
            inAdd.start(primaryStage);
        });
        
        // Update Button
        
        updateProduct.setOnMouseClicked(e ->
        {
             //Get selected product 
            Product prod = (Product) table.getSelectionModel().getSelectedItem();
            
            InventoryUpdate inUpdate = new InventoryUpdate(prod);
            inUpdate.start(primaryStage);
        });
        
        bp.setTop(hbtop);
        bp.setCenter(vb);
        bp.setBottom(hbbottom);
        bp.setPadding(new Insets(5));
        
        Scene scene = new Scene(bp, 850, 550);
        
        primaryStage.setTitle("Product List");
        primaryStage.setScene(scene);
        primaryStage.show();
    }
    
   
    
}
